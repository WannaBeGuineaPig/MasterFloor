﻿using MasterFloor.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MasterFloor
{
    /// <summary>
    /// Логика взаимодействия для ModulePartners.xaml
    /// </summary>
    public partial class ModulePartners : Window
    {
        DBDevoContext _dbDevoContext;
        public ModulePartners()
        {
            InitializeComponent();
            _dbDevoContext = new DBDevoContext();
            loadData();
        }

        void loadData()
        {
            allPartnersLV.ItemsSource = _dbDevoContext.GetPartners();
        }

        private void BackToMenuBtn_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}
