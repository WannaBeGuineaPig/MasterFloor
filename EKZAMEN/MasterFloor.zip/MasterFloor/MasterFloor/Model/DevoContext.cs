﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace MasterFloor.Model;

public partial class DevoContext : DbContext
{
    public DevoContext()
    {
    }

    public DevoContext(DbContextOptions<DevoContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Partner> Partners { get; set; }

    public virtual DbSet<PartnerProduct> PartnerProducts { get; set; }

    public virtual DbSet<PartnerType> PartnerTypes { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("host=localhost;user=root;password=root;database=devo", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.39-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Partner>(entity =>
        {
            entity.HasKey(e => e.Idpartner).HasName("PRIMARY");

            entity.ToTable("partner");

            entity.HasIndex(e => e.IdTypePartner, "id_type_fk_idx");

            entity.Property(e => e.Idpartner).HasColumnName("idpartner");
            entity.Property(e => e.Addres).HasColumnName("addres");
            entity.Property(e => e.FirstNameDirector)
                .HasMaxLength(45)
                .HasColumnName("first_name_director");
            entity.Property(e => e.IdTypePartner).HasColumnName("id_type_partner");
            entity.Property(e => e.Inn)
                .HasMaxLength(10)
                .HasColumnName("INN");
            entity.Property(e => e.LastNameDirector)
                .HasMaxLength(45)
                .HasColumnName("last_name_director");
            entity.Property(e => e.Mail)
                .HasMaxLength(255)
                .HasColumnName("mail");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
            entity.Property(e => e.Phone)
                .HasMaxLength(15)
                .HasColumnName("phone");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.SurnameDirector)
                .HasMaxLength(45)
                .HasColumnName("surname_director");

            entity.HasOne(d => d.IdTypePartnerNavigation).WithMany(p => p.Partners)
                .HasForeignKey(d => d.IdTypePartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_type_partner_fk");
        });

        modelBuilder.Entity<PartnerProduct>(entity =>
        {
            entity.HasKey(e => new { e.ArticulProduct, e.IdPartner })
                .HasName("PRIMARY")
                .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

            entity.ToTable("partner_product");

            entity.HasIndex(e => e.IdPartner, "partner_fk_idx");

            entity.Property(e => e.ArticulProduct).HasColumnName("articul_product");
            entity.Property(e => e.IdPartner).HasColumnName("id_partner");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.DateSale).HasColumnName("date_sale");

            entity.HasOne(d => d.ArticulProductNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.ArticulProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("articul_fk");

            entity.HasOne(d => d.IdPartnerNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.IdPartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("partner_fk");
        });

        modelBuilder.Entity<PartnerType>(entity =>
        {
            entity.HasKey(e => e.IdpartnerType).HasName("PRIMARY");

            entity.ToTable("partner_type");

            entity.Property(e => e.IdpartnerType).HasColumnName("idpartner_type");
            entity.Property(e => e.Type)
                .HasMaxLength(45)
                .HasColumnName("type");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Articul).HasName("PRIMARY");

            entity.ToTable("product");

            entity.HasIndex(e => e.IdTypeProduct, "id_type_fk_idx");

            entity.Property(e => e.Articul).HasColumnName("articul");
            entity.Property(e => e.IdTypeProduct).HasColumnName("id_type_product");
            entity.Property(e => e.MinPrice).HasColumnName("min_price");
            entity.Property(e => e.Name).HasColumnName("name");

            entity.HasOne(d => d.IdTypeProductNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.IdTypeProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_type_fk");
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.HasKey(e => e.IdproductType).HasName("PRIMARY");

            entity.ToTable("product_type");

            entity.Property(e => e.IdproductType).HasColumnName("idproduct_type");
            entity.Property(e => e.Koeffition)
                .HasPrecision(5, 2)
                .HasColumnName("koeffition");
            entity.Property(e => e.Type)
                .HasMaxLength(45)
                .HasColumnName("type");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
