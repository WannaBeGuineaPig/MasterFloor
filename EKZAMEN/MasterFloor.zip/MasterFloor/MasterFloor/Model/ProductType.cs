﻿using System;
using System.Collections.Generic;

namespace MasterFloor.Model;

public partial class ProductType
{
    public int IdproductType { get; set; }

    public string Type { get; set; } = null!;

    public decimal Koeffition { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
