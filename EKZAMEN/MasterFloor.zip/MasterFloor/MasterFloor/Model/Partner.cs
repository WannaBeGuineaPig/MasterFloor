﻿using System;
using System.Collections.Generic;

namespace MasterFloor.Model;

public partial class Partner
{
    public int Idpartner { get; set; }

    public int IdTypePartner { get; set; }

    public string Name { get; set; } = null!;

    public string LastNameDirector { get; set; } = null!;

    public string FirstNameDirector { get; set; } = null!;

    public string SurnameDirector { get; set; } = null!;
    public string FullName
    {
        get
        {
            return $"Директор: {LastNameDirector} {FirstNameDirector} {(SurnameDirector != null ? SurnameDirector : string.Empty)}";
        }
    }
    public string PartnerTypeName
    {
        get
        {
            return $"{IdTypePartnerNavigation.Type} | {Name}";
        }
    }

    public string Mail { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string Addres { get; set; } = null!;

    public string Inn { get; set; } = null!;

    public int Rating { get; set; }
    public string PartnerRating
    {
        get
        {
            return $"Рейтинг: {Rating}";
        }
    }
    public string PartnerDiscount
    {
        get
        {
            int sumCount = PartnerProducts.Sum(pp=>pp.Amount);
            if (sumCount < 10000) return "0%";
            else if (sumCount < 50000) return "5%";
            else if (sumCount < 300000) return "10%";
            else return "15%";
        }
    }

    public virtual PartnerType IdTypePartnerNavigation { get; set; } = null!;

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
