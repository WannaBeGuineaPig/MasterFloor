﻿using System;
using System.Collections.Generic;

namespace MasterFloor.Model;

public partial class Product
{
    public int Articul { get; set; }

    public int IdTypeProduct { get; set; }

    public string Name { get; set; } = null!;

    public double MinPrice { get; set; }

    public virtual ProductType IdTypeProductNavigation { get; set; } = null!;

    public virtual ICollection<PartnerProduct> PartnerProducts { get; set; } = new List<PartnerProduct>();
}
