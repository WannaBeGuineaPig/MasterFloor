﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterFloor.Model
{
    public class DBDevoContext
    {
        DevoContext _devoContext;
        public DBDevoContext()
        {
            _devoContext = new DevoContext();
        }

        public List<Partner> GetPartners()
        {
            return _devoContext.Partners.Include(tp => tp.IdTypePartnerNavigation).Include(p => p.PartnerProducts).ToList();
        }
    }
}
