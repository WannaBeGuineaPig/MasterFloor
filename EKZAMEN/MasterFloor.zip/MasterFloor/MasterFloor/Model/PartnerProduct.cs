﻿using System;
using System.Collections.Generic;

namespace MasterFloor.Model;

public partial class PartnerProduct
{
    public int ArticulProduct { get; set; }

    public int IdPartner { get; set; }

    public int Amount { get; set; }

    public DateOnly DateSale { get; set; }

    public virtual Product ArticulProductNavigation { get; set; } = null!;

    public virtual Partner IdPartnerNavigation { get; set; } = null!;
}
